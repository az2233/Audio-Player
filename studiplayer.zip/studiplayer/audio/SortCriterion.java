package studiplayer.audio;

public enum SortCriterion {
    DEFAULT, AUTHOR, TITLE, ALBUM, DURATION
}
